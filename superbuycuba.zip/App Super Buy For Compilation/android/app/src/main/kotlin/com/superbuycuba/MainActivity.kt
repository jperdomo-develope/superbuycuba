package com.superbuycuba

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}