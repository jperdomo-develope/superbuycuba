// lib/config.dart

const String wooCommerceBaseUrl = 'https://superbuycuba.com/wp-json/wc/v3/';
const String consumerKey = 'ck_7cc8b6abd58c7c681251ff8ccc0d970d51e2f854';
const String consumerSecret = 'cs_d97008ec114a88e53919ab20b3ed1c16f4d0a66b';

// Métodos de pago disponibles
const List<String> paymentMethods = [
  'Efectivo CUP',
  'Efectivo USD',
  'Efectivo Euro',
  'MLC',
  'Pago del exterior',
];

// Email de contacto (puede usarse para notificaciones o soporte)
const String contactEmail = 'superbuycuba@gmail.com';

// Roles
const String adminEmail = 'superbuycuba@gmail.com';